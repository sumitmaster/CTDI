﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CTDI.Models
{
    public class PuductDiscountedDetails
    {
        public int Product_ID { get; set; }
        public string Product_Name { get; set; }
        public float Product_Cost { get; set; }
        public DateTime Discount_TillDate { get; set; }
        public int Discount_Percentage { get; set; }
        public float Discounted_Product_Cost { get; set; }
    }
}