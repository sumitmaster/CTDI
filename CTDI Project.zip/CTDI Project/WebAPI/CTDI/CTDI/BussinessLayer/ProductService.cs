﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CTDI.Models;
using System.Collections;
using System.IO;
using Newtonsoft.Json;

namespace CTDI.BussinessLayer
{
    public class ProductService
    {

        /// <summary>
        /// This class is written by Sumit Kumar
        /// Below method will get data from Json File stored in App_Data folder
        /// </summary>
        /// <returns></returns>      
        public List<PuductDiscountedDetails> GetAllProducts(DateTime dt)
        {
            List<PuductDiscountedDetails> lstProducts = new List<PuductDiscountedDetails>();
            try
            {
                using (StreamReader r = new StreamReader
                    (System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/Products.json")))
                {
                    var json = r.ReadToEnd();
                    lstProducts = JsonConvert.DeserializeObject<List<PuductDiscountedDetails>>(json);
                    lstProducts = lstProducts.Where(d => d.Discount_TillDate == dt).ToList();
                }
            }
            catch (Exception ex)
            {
                ExcetpionLogging.CreateErrorMessage(ex);
            }
            return lstProducts;
        }

    }
}