export class Product {
    Product_ID:number;
    Product_Name:string;
    Product_Cost:number;
    Discount_Percentage:number;
    Discounted_Product_Cost:number;
    Discount_TillDate:Date;
}