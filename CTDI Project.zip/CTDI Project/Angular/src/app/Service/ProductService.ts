import { Injectable } from '@angular/core';
import { HttpClient,HttpParams  } from '@angular/common/http';
import {Product} from '../Models/Products';


@Injectable()
export class ProductService
{
    constructor(private objHttp:HttpClient)
    {

    }

    getProducts(dtDiscount)
    {
        let url ='http://localhost:51598/api/ProductDetails/';
        const params = new HttpParams()
        .set('dt', dtDiscount.date);

        return this.objHttp.get<Product[]>(url,{params});

    }
}