import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,FormControl,Validator} from '@angular/forms';
import {Product} from '../../Models/Products';
import {ProductService} from '../../Service/ProductService';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  providers:[ProductService]

})
export class ProductsComponent implements OnInit {

  ProductList:Product[]=[];
  fg:FormGroup;
  flag:string;
  constructor(private products:ProductService,private fb:FormBuilder) {    
    this.fg = fb.group({
      'date':''
    })
    this.flag='';
   }
   ngOnInit() {    
   }  

  GetProducts(dtDiscount)
  {
    this.flag='True';
    console.log(dtDiscount);
    this.products.getProducts(dtDiscount).subscribe(res=> {
      this.ProductList=res;
    },err=>{})

  }
}
